import { Injectable } from '@angular/core';

@Injectable()
export class EmpresasService {
  id: any;
  nome: any;
  cnpj: any;
}
