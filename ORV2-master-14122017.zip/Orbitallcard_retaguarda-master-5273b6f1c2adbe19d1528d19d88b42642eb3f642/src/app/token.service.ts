import { Injectable } from '@angular/core';

@Injectable()
export class TokenService {

  userToken: any;
  constructor() { }

}
